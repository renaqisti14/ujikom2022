<?php 
$koneksi = mysqli_connect("localhost", "root", "", "portofolio_rena");
// if($koneksi) echo "<h1>KONEK";